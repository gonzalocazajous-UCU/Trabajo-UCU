 Descripción
Flask es un microframework desarrollado en Python que permite crear aplicaciones web de manera sencilla, flexible y escalable. A diferencia de frameworks más pesados, Flask ofrece solo lo esencial, permitiendo al desarrollador elegir las herramientas que desea integrar.

Objetivo del proyecto
El objetivo de Flask es proporcionar una base ligera para el desarrollo web, facilitando la creación de APIs, aplicaciones web y servicios backend sin imponer una estructura rígida.

Instalación / uso
pip install flask

Recursos útiles
- Documentación oficial de Flask
- Tutoriales básicos de Python

Contribuciones
Este proyecto es open source, por lo que cualquier persona puede contribuir proponiendo mejoras mediante Pull Requests.

Licencia
Este proyecto utiliza la licencia BSD-3-Clause.