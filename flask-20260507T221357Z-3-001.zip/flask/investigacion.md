## Investigación

## ¿Qué es un Fork?
Un fork es una copia de un repositorio que se crea en tu propia cuenta de GitHub. Permite trabajar de forma independiente sobre un proyecto sin afectar el original.

## ¿Para qué se utiliza?
- Proponer mejoras
- Corregir errores
- Experimentar con cambios

## Implicancias de trabajar con un fork:
- No afecta el repositorio original
- Se pueden enviar Pull Requests
- Se debe sincronizar con el repo original si hay cambios

## Diferencia entre Fork y Clone:
- Fork: copia en GitHub
- Clone: copia en tu computadora

---

## Licenciamiento:
El proyecto Flask utiliza la licencia BSD-3-Clause.

## Tipo de licencia:
Licencia permisiva

## Permite:
- Uso comercial
- Modificación
- Distribución

## Restricciones:
- Mantener aviso de copyright
- No usar el nombre del autor para promoción

## ¿Debo usar licencia en facultad?
Sí, es recomendable.

## ¿Cuál usar?
MIT o BSD (simples y permisivas)

## Reflexión

GitHub cumple un rol central en el desarrollo open source ya que permite:
- Colaboración global
- Control de versiones
- Gestión de proyectos

Las prácticas se estandarizan porque:
- Facilitan el trabajo en equipo
- Reducen errores
- Mejoran la organización

La documentación es fundamental porque:
- Permite entender el proyecto
- Facilita la colaboración
- Reduce la curva de aprendizaje